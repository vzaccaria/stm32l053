var group___c_m_s_i_s___r_t_o_s___status =
[
    [ "osStatus", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99e", [
      [ "osOK", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea9e1c9e2550bb4de8969a935acffc968f", null ],
      [ "osEventSignal", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea5df7e9643aa8a2f5f3a6f6ec59758518", null ],
      [ "osEventMessage", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ead604f3673359dd4ac643b16dc5a2c342", null ],
      [ "osEventMail", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea15b12e42b42b53f35fb8a2724ad02926", null ],
      [ "osEventTimeout", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea78f477732375c0e1fca814e369618177", null ],
      [ "osErrorParameter", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99eac24adca6a5d072c9f01c32178ba0d109", null ],
      [ "osErrorResource", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea8fc5801e8b0482bdf22ad63a77f0155d", null ],
      [ "osErrorTimeoutResource", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea314d24a49003f09459035db0dd7c9467", null ],
      [ "osErrorISR", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea21635bdc492d3094fe83027fa4a30e2f", null ],
      [ "osErrorISRRecursive", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99eaf6552310a817452aedfcd453f2805d65", null ],
      [ "osErrorPriority", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99eab7dda0ef504817659334cbfd650ae56f", null ],
      [ "osErrorNoMemory", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99eaf1fac0240218e51eb30a13da2f8aae81", null ],
      [ "osErrorValue", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea4672c8a0c0f6bb1d7981da4602e8e9ee", null ],
      [ "osErrorOS", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99ea5fde24ff588ec5ab9cb8314bade26fbc", null ],
      [ "os_status_reserved", "group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99eac7a77f5fe18a15a357790c36a4aca1b1", null ]
    ] ]
];